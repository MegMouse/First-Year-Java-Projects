import javax.swing.JOptionPane;
public class JavaSwingIntro
{
    public static void main(String[] args)
    {
        JOptionPane.showMessageDialog(null, "Hello, Software Development!");
    }
}

